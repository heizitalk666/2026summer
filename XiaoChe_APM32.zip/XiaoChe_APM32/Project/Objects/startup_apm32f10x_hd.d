.\objects\startup_apm32f10x_hd.o: ..\Source\Libraries\Device\Geehy\APM32F10x\Source\arm\startup_apm32f10x_hd.s

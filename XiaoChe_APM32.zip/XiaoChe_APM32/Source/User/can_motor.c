#include "can_motor.h"
#include "rtthread.h"
/** @defgroup CAN_Normal_Variables Variables
  @{
  */



can_motor_fbk_t g_MotorFbk[4];

CAN_TxMessage_T TxMessage;
CAN_RxMessage_T RxMessage;




/*!
 * @brief   GPIO Init
 *
 * @param   None
 *
 * @retval  None
 *
 */
void CAN_GPIO_Init(void)
{
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_AFIO);
    RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOA | RCM_APB2_PERIPH_GPIOB);

    GPIO_Config_T configStruct;

    GPIO_ConfigPinRemap(GPIO_REMAP1_CAN1);
    configStruct.pin = GPIO_PIN_9; // CAN1 Tx remap 1
    configStruct.mode = GPIO_MODE_AF_PP;
    configStruct.speed = GPIO_SPEED_50MHz;
    GPIO_Config(GPIOB, &configStruct);

    configStruct.pin = GPIO_PIN_8; // CAN1 Rx remap 1
    configStruct.mode = GPIO_MODE_IN_PU;
    GPIO_Config(GPIOB, &configStruct);
	
	configStruct.pin = GPIO_PIN_11; // motor power
    configStruct.mode = GPIO_MODE_OUT_PP;
    configStruct.speed = GPIO_SPEED_2MHz;
    GPIO_Config(GPIOA, &configStruct);
	
	motor_power_on();
}

/*!
 * @brief   CAN Init
 *
 * @param   None
 *
 * @retval  None
 *
 */
void CAN_Config_Init(void)
{
    RCM_EnableAPB1PeriphClock(RCM_APB1_PERIPH_CAN1);//48m

    CAN_Config_T canConfig;
    CAN_FilterConfig_T FilterStruct;

    CAN_Reset(CAN1);

    CAN_ConfigStructInit(&canConfig);

    /* CAN1 and CAN2  init */
    canConfig.autoBusOffManage = DISABLE;
    canConfig.autoWakeUpMode = DISABLE;
    canConfig.nonAutoRetran = DISABLE;
    canConfig.rxFIFOLockMode = DISABLE;
    canConfig.txFIFOPriority = ENABLE;
    canConfig.mode = CAN_MODE_NORMAL;
    canConfig.syncJumpWidth = CAN_SJW_1;
	//1000K sq=75% err=0
//    canConfig.timeSegment1 = CAN_TIME_SEGMENT1_2;
//    canConfig.timeSegment2 = CAN_TIME_SEGMENT2_1;
//    canConfig.prescaler = 12;

	//500K sq=87.5% err=0
    canConfig.timeSegment1 = CAN_TIME_SEGMENT1_6;
    canConfig.timeSegment2 = CAN_TIME_SEGMENT2_1;
    canConfig.prescaler = 12;
	
    CAN_Config(CAN1, &canConfig);

    FilterStruct.filterNumber = 1;
    FilterStruct.filterMode = CAN_FILTER_MODE_IDMASK;
    FilterStruct.filterScale = CAN_FILTER_SCALE_32BIT;
    FilterStruct.filterIdHigh = 0x0000;
    FilterStruct.filterIdLow = 0x0000;
    FilterStruct.filterMaskIdHigh = 0x0000;
    FilterStruct.filterMaskIdLow = 0x0000;
    FilterStruct.filterFIFO = CAN_FILTER_FIFO_0;
    FilterStruct.filterActivation = ENABLE;

    CAN_ConfigFilter(CAN1, &FilterStruct);

    NVIC_EnableIRQRequest(USBD1_LP_CAN1_RX0_IRQn, 0, 0);
}

/*!
 * @brief   CAN Transmit Init
 *
 * @param   None
 *
 * @retval  None
 *
 */
void CAN_Transmit_Init(void)
{
    TxMessage.stdID = 0x321;
    TxMessage.extID = 0x01;
    TxMessage.remoteTxReq = CAN_RTXR_DATA;
    TxMessage.typeID = CAN_TYPEID_STD;
    TxMessage.dataLengthCode = 1;
}

/*!
 * @brief   CAN1 Rx interrupt
 *
 * @param   None
 *
 * @retval  None
 *
 */
void CAN1_RX0_ISR(void)
{
    CAN_RxMessage(CAN1, CAN_RX_FIFO_0, &RxMessage);

	if(RxMessage.stdID > 0x96 && RxMessage.stdID < 0x9B)
	{
		uint8_t index = RxMessage.stdID - 0x97;
		uint8_t* buff = (uint8_t*)&g_MotorFbk[index];
		rt_memcpy(buff, RxMessage.data, 8);
	}
	
//    if ((RxMessage.stdID == 0x321) && (RxMessage.typeID == CAN_TYPEID_STD) && (RxMessage.dataLengthCode == 1) && (RxMessage.data[0] == 0xAA))
//    {
//        rt_kprintf("CAN1 Receive 0xAA !\r\n");
//    }
//    else
//    {
//        rt_kprintf("CAN1 Receive Error !\r\n");
//    }
}

void can_motor_init(void)
{
    CAN_GPIO_Init();
    CAN_Config_Init();
    CAN_EnableInterrupt(CAN1, CAN_INT_F0MP);
}

void can_motor_1_4_set_mode(uint8_t* mode)
{
	CAN_TxMessage_T TxMeg;
	TxMeg.stdID = 0x105;
    TxMeg.extID = 0;
    TxMeg.remoteTxReq = CAN_RTXR_DATA;
    TxMeg.typeID = CAN_TYPEID_STD;
    TxMeg.dataLengthCode = 8;
	rt_memcpy(TxMeg.data, (uint8_t*)mode, 4);
	rt_memset(&TxMeg.data[4], 0, 4);
	CAN_TxMessage(CAN1, &TxMeg);
}

void can_motor_1_4_set_enable(uint8_t* enable)
{
	CAN_TxMessage_T TxMeg;
	TxMeg.stdID = 0x105;
    TxMeg.extID = 0;
    TxMeg.remoteTxReq = CAN_RTXR_DATA;
    TxMeg.typeID = CAN_TYPEID_STD;
    TxMeg.dataLengthCode = 8;
	rt_memcpy(TxMeg.data, (uint8_t*)enable, 4);
	rt_memset(&TxMeg.data[4], 0, 4);
	CAN_TxMessage(CAN1, &TxMeg);
}

void can_motor_1_4_set_fbk(uint8_t* fbk)
{
	CAN_TxMessage_T TxMeg;
	TxMeg.stdID = 0x105;
    TxMeg.extID = 0;
    TxMeg.remoteTxReq = CAN_RTXR_DATA;
    TxMeg.typeID = CAN_TYPEID_STD;
    TxMeg.dataLengthCode = 8;
	rt_memcpy(TxMeg.data, (uint8_t*)fbk, 4);
	rt_memset(&TxMeg.data[4], 0x80, 4);
	CAN_TxMessage(CAN1, &TxMeg);
}

void can_motor_1_4_set_value(int16_t* value)
{
	CAN_TxMessage_T TxMeg;
	TxMeg.stdID = 0x32;
    TxMeg.extID = 0;
    TxMeg.remoteTxReq = CAN_RTXR_DATA;
    TxMeg.typeID = CAN_TYPEID_STD;
    TxMeg.dataLengthCode = 8;
	rt_memcpy(TxMeg.data, (uint8_t*)value, 8);

	CAN_TxMessage(CAN1, &TxMeg);
}



void can_motor_set_spd_rpm(int16_t* rpm)
{
	int16_t tmp[4];
	
	tmp[MOTOR1_BUFFER_INDEX] = rpm[0];
	tmp[MOTOR2_BUFFER_INDEX] = rpm[1];
	tmp[MOTOR3_BUFFER_INDEX] = rpm[2];
	tmp[MOTOR4_BUFFER_INDEX] = rpm[3];
	
	can_motor_1_4_set_value(tmp);
}

#include <stdio.h>
#include <math.h>
// �����ֵ�����M_PIδ��������
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ���̲�������
#define WHEEL_DIAMETER 0.2054f      // ����ֱ��(m)
#define WHEEL_RADIUS (WHEEL_DIAMETER / 2.0f)  // ���Ӱ뾶(m)
#define WHEEL_DISTANCE 0.5165f      // �Խ����Ӿ���(m)
#define L (WHEEL_DISTANCE / sqrt(2.0f))  // ���ĵ㵽���ӵľ���

// �����ĸ����ӵ�ת��(rpm)
void calculateWheelSpeeds(float vx, float vy, float omega, float *wheelSpeeds) {
    // ���ٶ�ת��Ϊ���ٶ� (rad/s)
    float omega_vx = vx / WHEEL_RADIUS;
    float omega_vy = vy / WHEEL_RADIUS;
    
    // ����Y�᷽�򣺽���vy�ķ���
    // �����ĸ����ӵ�ת�� (rad/s)
    wheelSpeeds[0] = omega_vx + omega_vy + omega * L;  // ������
    wheelSpeeds[1] = omega_vx - omega_vy + omega * L;  // ������
    wheelSpeeds[2] = omega_vx + omega_vy - omega * L;  // ������
    wheelSpeeds[3] = omega_vx - omega_vy - omega * L;  // ������
    
    // �����ٶ�ת��Ϊת�� (rpm)
    for (int i = 0; i < 4; i++) {
        wheelSpeeds[i] = wheelSpeeds[i] * 60.0f / (2.0f * M_PI);
    }
}

// �޷�������ȷ������ת���ں�����Χ��
void limitWheelSpeeds(float *wheelSpeeds, float maxRpm) {
    for (int i = 0; i < 4; i++) {
        if (wheelSpeeds[i] > maxRpm) {
            wheelSpeeds[i] = maxRpm;
        } else if (wheelSpeeds[i] < -maxRpm) {
            wheelSpeeds[i] = -maxRpm;
        }
    }
}

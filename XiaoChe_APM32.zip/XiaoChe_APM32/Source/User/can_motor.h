#ifndef __CAN_MOTOR_H
#define __CAN_MOTOR_H

#include "apm32f10x.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_usart.h"
#include "apm32f10x_misc.h"
#include "apm32f10x_can.h"
#ifdef __cplusplus
extern "C"
{
#endif



typedef struct
{
	int16_t rpm;
	int16_t current;
	int16_t position;
	uint8_t err;
	uint8_t mode;
}can_motor_fbk_t;

typedef enum
{
	MOTOR1_ID = 4,
	MOTOR2_ID = 3,
	MOTOR3_ID = 2,
	MOTOR4_ID = 1,
}motor_id_enum;

typedef enum
{
	MOTOR1_BUFFER_INDEX = MOTOR1_ID - 1,
	MOTOR2_BUFFER_INDEX = MOTOR2_ID - 1,
	MOTOR3_BUFFER_INDEX = MOTOR3_ID - 1,
	MOTOR4_BUFFER_INDEX = MOTOR4_ID - 1,
}motor_buffer_index_enum;

#define motor_power_on()	(GPIOA->BSC = (uint32_t)GPIO_PIN_11)
#define motor_power_off()	(GPIOA->BC = (uint32_t)GPIO_PIN_11)



extern can_motor_fbk_t g_MotorFbk[];




void can_motor_init(void);
void can_motor_1_4_set_mode(uint8_t* mode);
void can_motor_1_4_set_enable(uint8_t* enable);
void can_motor_1_4_set_fbk(uint8_t* fbk);
void can_motor_1_4_set_value(int16_t* value);

void can_motor_set_spd_rpm(int16_t* rpm);

void calculateWheelSpeeds(float vx, float vy, float omega, float *wheelSpeeds);
void limitWheelSpeeds(float *wheelSpeeds, float maxRpm);

#ifdef __cplusplus
}
#endif
#endif

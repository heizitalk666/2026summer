/*!
    \file    systick.c
    \brief   the systick configuration file
    
    \version 2020-12-31, V1.0.0, firmware for GD32C10x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/


#include "delay.h"
#include <rtthread.h>
#define CPU_FREQ					96000000
#define SYSTICK_1MS_TICKS    		(CPU_FREQ/1000)
#define SYSTICK_uS_PER_TICK      	1000L/SYSTICK_1MS_TICKS
volatile uint32_t uwTick = 0;
/*!
    \brief      configure systick
    \param[in]  none
    \param[out] none
    \retval     none
*/
//void systick_config(void)
//{
//    /* setup systick timer for 1000Hz interrupts */
//    if (SysTick_Config(SystemCoreClock / 1000U)){
//        /* capture error */
//        while (1){
//        }
//    }
//    /* configure the systick handler priority */
//    NVIC_SetPriority(SysTick_IRQn, 0x00U);
//}

/*!
    \brief      get system ms count
    \param[in]  none
    \param[out] none
    \retval     ms
*/
uint32_t getms(void)
{
    return uwTick;
}
/*!
    \brief      get system ms count
    \param[in]  none
    \param[out] none
    \retval     ms
*/
uint64_t getus(void)
{
    register uint32_t cached_ms, cached_tick;

    uint32_t context = enter_critical_section();

    cached_ms = uwTick;
    cached_tick = SysTick->VAL;

    if (SCB->ICSR & SCB_ICSR_PENDSTSET_Msk) {
        ++cached_ms;
        cached_tick = SysTick->VAL;
    }

    leave_critical_section(context);

    return (uint64_t)cached_ms*1000 + ((SYSTICK_1MS_TICKS -1 - cached_tick)*SYSTICK_uS_PER_TICK);

}
/*!
    \brief      delay a time in milliseconds
	\param[in]  ms : delay time (in milliseconds)
    \param[out] none
    \retval     none
*/
void delay_ms(uint32_t ms)
{
    uint32_t targettime = getms() + ms;

    while( getms() < targettime);
}
/*!
    \brief      delay a time in microseconds
	\param[in]  us : delay time (in us)
    \param[out] none
    \retval     none
*/
void delay_us(uint32_t us)
{
    uint64_t targettime = getus() + us;
	rt_enter_critical();
    while( getus() < targettime);
	rt_exit_critical();
}

#ifndef __DELAY_H
#define __DELAY_H

#include "apm32f10x.h"


#define cli __disable_irq
#define sei __enable_irq

static inline uint32_t enter_critical_section(void)
{
    uint32_t context=__get_PRIMASK();
    cli();
    return context;
}

static inline void leave_critical_section(uint32_t context)
{
    __set_PRIMASK(context);
}

extern volatile uint32_t uwTick;





//extern void systick_config(void);
extern uint32_t getms(void);
extern uint64_t getus(void);
extern void delay_ms(uint32_t ms);
extern void delay_us(uint32_t us);
















#endif

/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.2
 *
 * @date        2022-12-01
 *
 * @attention
 *
 *  Copyright (C) 2020-2022 Geehy Semiconductor
 *
 *  You may not use this file except in compliance with the
 *  GEEHY COPYRIGHT NOTICE (GEEHY SOFTWARE PACKAGE LICENSE).
 *
 *  The program is only for reference, which is distributed in the hope
 *  that it will be useful and instructional for customers to develop
 *  their software. Unless required by applicable law or agreed to in
 *  writing, the program is distributed on an "AS IS" BASIS, WITHOUT
 *  ANY WARRANTY OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the GEEHY SOFTWARE PACKAGE LICENSE for the governing permissions
 *  and limitations under the License.
 */

/* Includes */
#include "main.h"
#include "rtthread.h"
#include "ps2.h"
#include "delay.h"
#include "can_motor.h"

#define PS_GEAR 7
#define MAX_SPD		0.1f // m/s
#define MAX_OMEGA	3.14f // rad/s


/** @addtogroup Examples
  @{
  */

/** @addtogroup GPIO_Toggle
  @{
  */

/** @defgroup GPIO_Toggle_Functions Functions
  @{
  */
// static rt_thread_t led1_thread = RT_NULL;
// static void led1_thread_entry(void* parameter);

// static void led1_thread_entry(void* parameter)
// {
//     while (1)
//     {
//         rt_thread_delay(1000);
//     }
// }


uint8_t flag = 0;
int16_t value[4];
float vx = 0,vy = 0,omega = 0;
/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 */
int main(void)
{
	uint8_t data[4];
	int16_t tmpx = 0, tmpy = 0, tmpz = 0;
	uint16_t PS2_KEYMASK_Last = 0;
	uint8_t start = 0;
	uint8_t gear = 0;
	float wheel_spd_f[4];
	int16_t wheel_rpm[4];
	uint8_t count_timeout = 0;


	
	PS2_Init();

    can_motor_init();
	
	rt_thread_mdelay(3000);
	
	rt_memset(data, 0x02, 4);
	can_motor_1_4_set_mode(data);
	rt_thread_mdelay(100);
	
	rt_memset(data, 0x80, 4);
	can_motor_1_4_set_fbk(data);
	rt_thread_mdelay(100);
	
	
	
	
    while (1)
    {
		if(flag)
		{
			flag = 0;
			
			
			
			calculateWheelSpeeds(vx, vy, omega, wheel_spd_f);
			limitWheelSpeeds(wheel_spd_f, 210);
			
			wheel_rpm[0] = -wheel_spd_f[0];	//������
			wheel_rpm[1] = -wheel_spd_f[1];	//������
			wheel_rpm[2] = wheel_spd_f[2];	//������
			wheel_rpm[3] = wheel_spd_f[3];	//������
			
			can_motor_1_4_set_value(wheel_rpm);
		}
		
		
		PS2_KEYMASK = PS2_DataKeyMask();
		if(Data[2] == 0x5A)
		{
            if(Data[1] != 0x73)
            {
                PS2_Init();
                //PS2_SetInit();
                rt_thread_mdelay(5);
                PS2_KEY = PS2_DataKey();
            }
			
			PS2_LX = PS2_AnologData(PSS_LX);
			PS2_LY = PS2_AnologData(PSS_LY);
			PS2_RX = PS2_AnologData(PSS_RX);
			PS2_RY = PS2_AnologData(PSS_RY);
			
			if(!(PS2_KEYMASK_Last&PSB_START_MASK) && (PS2_KEYMASK&PSB_START_MASK))
			{
				if(start)
					start = 0;
				else
					start = 1;
			}

			if(!(PS2_KEYMASK_Last&PSB_TRIANGLE_MASK) && (PS2_KEYMASK&PSB_TRIANGLE_MASK))
			{
				if(gear < 2)
				{
					gear += 1;
				}
			}

			if(!(PS2_KEYMASK_Last&PSB_CROSS_MASK) && (PS2_KEYMASK&PSB_CROSS_MASK))
			{
				if(gear > 0)
				{
					gear -= 1;
				}
			}
			
			if(PS2_LY==255 && PS2_LX==255 && PS2_RX==255 && PS2_RY==255)
			{
				start = 0;
				wheel_rpm[0] = 0;
				wheel_rpm[1] = 0;
				wheel_rpm[2] = 0;
				wheel_rpm[3] = 0;
				can_motor_1_4_set_value(wheel_rpm);
			}
			
			if(PS2_LY <= (127-PS_GEAR)) //up
			{
				tmpx = 127 - PS_GEAR - PS2_LY;
				tmpx = tmpx*100/(127 - PS_GEAR);
			}
			else if(PS2_LY >= (128 + PS_GEAR)) //down
			{
				tmpx = PS2_LY - 128 - PS_GEAR;
				tmpx = -tmpx*100/(127 - PS_GEAR);
			}
			else
				tmpx = 0;
			
			if(PS2_LX <= (127-PS_GEAR)) //up
			{
				tmpy = 127 - PS_GEAR - PS2_LX;
				tmpy = tmpy*100/(127 - PS_GEAR);
			}
			else if(PS2_LX >= (128 + PS_GEAR)) //down
			{
				tmpy = PS2_LX - 128 - PS_GEAR;
				tmpy = -tmpy*100/(127 - PS_GEAR);
			}
			else
				tmpy = 0;			
			
			if(PS2_RX <= (127-PS_GEAR)) //left
			{
				tmpz = 127 - PS_GEAR - PS2_RX;
				tmpz = tmpz*100/(127 - PS_GEAR);
			}
			else if(PS2_RX >= (128 + PS_GEAR)) //right
			{
				tmpz = PS2_RX - 128 - PS_GEAR;
				tmpz = -tmpz*100/(127 - PS_GEAR);
			}
			else
				tmpz = 0;
		

			if(tmpx > 100)
				tmpx = 100;
			if(tmpx < -100)
				tmpx -= 100;
	
			if(tmpy > 100)
				tmpy = 100;
			if(tmpy < -100)
				tmpy -= 100;
			
			if(tmpz > 100)
				tmpz = 100;
			if(tmpz < -100)
				tmpz -= 100;
			
			value[0] = tmpx;
			value[1] = tmpy;
			value[2] = tmpz;
			
			if(start)
			{
				rt_kprintf("LX:%d LY:%d RX:%d RY:%d    Start:%d      \r", PS2_LX, PS2_LY, PS2_RX, PS2_RY, start);
				
				vx = (float)tmpx * MAX_SPD * (gear + 1) / 100;
				vy = (float)tmpy * MAX_SPD * (gear + 1) / 100;
				omega = (float)tmpz * MAX_OMEGA / 100;
				
				
				calculateWheelSpeeds(vx, vy, omega, wheel_spd_f);
				limitWheelSpeeds(wheel_spd_f, 210);
				
				wheel_rpm[0] = -wheel_spd_f[0];	//������
				wheel_rpm[1] = -wheel_spd_f[1];	//������
				wheel_rpm[2] = wheel_spd_f[2];	//������
				wheel_rpm[3] = wheel_spd_f[3];	//������
				
				can_motor_1_4_set_value(wheel_rpm);
			}
			
			PS2_KEYMASK_Last = PS2_KEYMASK;
		}
		else
		{
			if(count_timeout >= 4)
			{
				count_timeout = 0;
				start = 0;
				wheel_rpm[0] = 0;
				wheel_rpm[1] = 0;
				wheel_rpm[2] = 0;
				wheel_rpm[3] = 0;
				can_motor_1_4_set_value(wheel_rpm);
			}
			else
				count_timeout ++;
		}
		
		rt_thread_delay(50);
	}
}

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      None
 *
 */
void Delay(void)
{
    volatile uint32_t delay = 0xfffff;

    while(delay--);
}

/**@} end of group GPIO_Toggle_Functions */
/**@} end of group GPIO_Toggle */
/**@} end of group Examples */

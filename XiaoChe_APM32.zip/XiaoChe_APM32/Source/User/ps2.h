#ifndef __PS2_H
#define __PS2_H

#include "apm32f10x.h"
#include "apm32f10x_gpio.h"
#include "apm32f10x_rcm.h"
#include "apm32f10x_eint.h"
#include "apm32f10x_usart.h"
#include "apm32f10x_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#define ps2_cs_disable()   		(GPIOA->BSC = GPIO_PIN_4)
#define ps2_cs_enable()   		(GPIOA->BC = GPIO_PIN_4)

#define DI   					GPIO_ReadInputBit(GPIOA, GPIO_PIN_6) 	//DAT 	PA6

#define DO_H 					GPIOA->BSC = GPIO_PIN_5					//CMD 	PA5
#define DO_L 					GPIOA->BC = GPIO_PIN_5

#define CS_H 					GPIOA->BSC = GPIO_PIN_4					//CS 	PA4
#define CS_L 					GPIOA->BC = GPIO_PIN_4

#define CLK_H 					GPIOA->BSC = GPIO_PIN_3					//CLK	PA3
#define CLK_L 					GPIOA->BC = GPIO_PIN_3

//These are our button constants
#define PSB_SELECT      1
#define PSB_L3          2
#define PSB_R3          3
#define PSB_START       4
#define PSB_PAD_UP      5
#define PSB_PAD_RIGHT   6
#define PSB_PAD_DOWN    7
#define PSB_PAD_LEFT    8
#define PSB_L2          9
#define PSB_R2          10
#define PSB_L1          11
#define PSB_R1          12
#define PSB_GREEN       13
#define PSB_RED         14
#define PSB_BLUE        15
#define PSB_PINK        16

#define PSB_TRIANGLE    13
#define PSB_CIRCLE      14
#define PSB_CROSS       15
#define PSB_SQUARE      16

//#define WHAMMY_BAR        8

//These are stick values
#define PSS_RX 5                //��ҡ��X������
#define PSS_RY 6
#define PSS_LX 7
#define PSS_LY 8

#define PSB_SELECT_MASK         (uint16_t)0x0001
#define PSB_L3_MASK             (uint16_t)0x0002
#define PSB_R3_MASK             (uint16_t)0x0004
#define PSB_START_MASK          (uint16_t)0x0008
#define PSB_PAD_UP_MASK         (uint16_t)0x0010
#define PSB_PAD_RIGHT_MASK      (uint16_t)0x0020
#define PSB_PAD_DOWN_MASK       (uint16_t)0x0040
#define PSB_PAD_LEFT_MASK       (uint16_t)0x0080
#define PSB_L2_MASK             (uint16_t)0x0100
#define PSB_R2_MASK             (uint16_t)0x0200
#define PSB_L1_MASK             (uint16_t)0x0400
#define PSB_R1_MASK             (uint16_t)0x0800

#define PSB_GREEN_MASK          (uint16_t)0x1000
#define PSB_RED_MASK            (uint16_t)0x2000
#define PSB_BLUE_MASK           (uint16_t)0x4000
#define PSB_PINK_MASK           (uint16_t)0x8000
#define PSB_TRIANGLE_MASK       PSB_GREEN_MASK
#define PSB_CIRCLE_MASK         PSB_RED_MASK
#define PSB_CROSS_MASK          PSB_BLUE_MASK
#define PSB_SQUARE_MASK         PSB_PINK_MASK






extern uint16_t PS2_KEYMASK;
extern int PS2_LX,PS2_LY,PS2_RX,PS2_RY, PS2_KEY;
extern u8 Data[9];
extern u16 MASK[16];
extern u16 Handkey;

void PS2_Init(void);
u8 PS2_RedLight(void);   //�ж��Ƿ�Ϊ���ģʽ
void PS2_ReadData(void); //���ֱ�����
void PS2_Cmd(u8 CMD);         //���ֱ���������
u8 PS2_DataKey(void);         //����ֵ��ȡ
uint16_t PS2_DataKeyMask(void);
u8 PS2_AnologData(u8 button); //�õ�һ��ҡ�˵�ģ����
void PS2_ClearData(void);     //������ݻ�����
void PS2_Vibration(u8 motor1, u8 motor2);//������motor1  0xFF���������أ�motor2  0x40~0xFF
void delay_us(u32 nus);
void PS2_EnterConfing(void);     //��������
void PS2_TurnOnAnalogMode(void); //����ģ����
void PS2_VibrationMode(void);    //������
void PS2_ExitConfing(void);      //�������
void PS2_SetInit(void);          //���ó�ʼ��
int PS2_DataMode(void);


#ifdef __cplusplus
}
#endif
#endif
